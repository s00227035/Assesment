﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            

            string [] results = { "W, D, D, L, W, W, D, L, W, W" };

            int totalPoints = 0, wins = 3, draw = 1, loss = 0;

            for (int i = 0; i < length; i++)
            {

            }
        }
    }
}
