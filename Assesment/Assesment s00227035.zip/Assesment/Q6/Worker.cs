﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q6
{
    public class Worker
    {
        public string Name { get; set; }

        public string Type { get; set; }

        public decimal HourlyRate { get; set; }
    }
}
